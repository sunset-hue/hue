"""
# discmoji.cli
Contains the source code for the CLI, and some extra utilities, such as checks and logging."""

from ...discmoji import *
from ._cli import __CLI__
