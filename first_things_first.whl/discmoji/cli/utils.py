"""
    # discmoji.cli.utils
    contains useful utilities that can be used for checks. Most checks that are not integrated into the 
    structures themselves are here.
"""

...