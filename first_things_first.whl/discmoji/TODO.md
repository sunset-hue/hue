# TODO

- Permission Overwrites Object :white_check_mark: ~ :large_orange_diamond: (finished, but need finishing touches)
- make asset object
- make prefix commands work properly :large_orange_diamond:
- make slash commands
- Add new functions/functionality to classes
- Message related objects :white_check_mark:

|In progress = :large_orange_diamond: | Not done = :x: | Done = :white_check_mark:|